import React, { useState } from "react";

function RecipeCreate({recipes, setRecipes}) {
  
  const initialFormState = {
      name: "",
      cuisine: "",
      photo: "",
      ingredients: "",
      preparation: "",
  }
  const [formData, setFormData] = useState({...initialFormState});
  
  const handleChange = ({target}) => {
    setFormData({
      ...formData, [target.name]: target.value,
    })
  }
  
  const handleSubmit = (event) => {
    event.preventDefault();
    const addRecipes = {
      //id: recipes.length + 1,
      name: formData.name,
      cuisine: formData.cuisine,
      photo: formData.photo,
      ingredients: formData.ingredients,
      preparation: formData.preparation,
    }
    setRecipes([...recipes, addRecipes])
    setFormData({...initialFormState})
  }
  

  // TODO: When the form is submitted, a new recipe should be created, and the form contents cleared.
  // TODO: Add the required input and textarea form elements.
  // TODO: Add the required submit and change handlers
  
  return (
    <form onSubmit={handleSubmit} name="create">
      <table>
        <tbody>
          <tr>
            <td>
            <label htmlFor="name">
        <input
          id="name"
          type="text"
          name="name"
          onChange={handleChange}
          value={formData.name}
        />
      </label>
            </td>
            <td>
            <label htmlFor="cuisine">
        <input
          id="cuisine"
          type="text"
          name="cuisine"
          onChange={handleChange}
          value={formData.cuisine}
        />
      </label>
            </td>
            <td>
              <label htmlFor="photo"></label>
            <input 
              id="photo" 
              name="photo" 
              type="url" 
              required={true} 
              onChange={handleChange}
              value={formData.photo}
              />
            </td>
            <td>
              <label htmlFor="ingredients"></label>
            <textarea 
              id="ingredients" 
              name="ingredients" 
              required={true} 
              rows={3} 
              onChange={handleChange}
              value={formData.ingredients}
              />
            </td>
            <td>
             <label htmlFor="preparation"></label>
              <textarea 
              id="preparation" 
              name="preparation" 
              required={true} 
              rows={3} 
              onChange={handleChange}
              value={formData.preparation}
              />
            </td>
            <td></td>
            <td>
              <button type="submit">Create</button>
            </td>
          </tr>
        </tbody>
      </table>
    </form>
  );
}

export default RecipeCreate;
